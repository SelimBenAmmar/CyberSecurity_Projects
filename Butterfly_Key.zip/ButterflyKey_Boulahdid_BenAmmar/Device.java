import org.bouncycastle.jce.spec.ECParameterSpec;
import java.security.KeyPairGenerator;
import java.security.Provider;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.KeyGenerator;
import javax.crypto.*;
import java.math.BigInteger;
import java.util.ArrayList;
import javax.crypto.Cipher;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.*;
import java.security.Signature;




class Device{

    private KeyPair keyPairA;
    private KeyPair keyPairP;
    private SecretKey secretSign;
    private SecretKey secretEncrypt;
    private String name;
    private CA ca;
    private ECPoint  generatorPoint;
    private ECPoint  pointA;
    private ECPoint  pointP;

    public Device(String n,CA c){
      name = n;
      ca   = c;
      Security.addProvider(new BouncyCastleProvider());

      // Generate 2 pairs of public and private keys with ECDSA (a,A) and (p,P)
      try {
          KeyPairGenerator kpg = KeyPairGenerator.getInstance("ECDSA", BouncyCastleProvider.PROVIDER_NAME);
          kpg.initialize(new ECGenParameterSpec(name));
          keyPairA = kpg.generateKeyPair();
          keyPairP = kpg.generateKeyPair();
      } catch(Exception e) {
          e.printStackTrace();
      }

      //Generate 2 AES 128-bit keys : signing key (ck) and encrypting key (ek)
      try{
          KeyGenerator gen = KeyGenerator.getInstance("AES");
          gen.init(128); /* 128-bit AES */
          secretSign = gen.generateKey();
          secretEncrypt = gen.generateKey();

          }catch(Exception e){
            e.printStackTrace();
          }

      initCurvParam();
    }

    /* We initialize the elliptic curve we are going to work on.
    We focus on the three following variables: generatorPoint (G), pointA, pointP
    */
    private void initCurvParam(){
      X9ECParameters curveParam = X962NamedCurves.getByName(name);
      generatorPoint = curveParam.getG();

      //initialize pointA and pointP
      ECCurve.Fp curve = (ECCurve.Fp)curveParam.getCurve();
      // BigInteger q     = curve.getQ();
      String sA        = keyPairA.getPublic().toString();
      String sP        = keyPairP.getPublic().toString();

      pointA = curve.createPoint(new BigInteger(sA.substring(29,93),16),
                                  new BigInteger(sA.substring(109,173),16), false);;
      /*
      pointP = curve.createPoint(new BigInteger(sP.substring(29,93),16),
                                  new BigInteger(sP.substring(109,173),16), false);
      */
    }

    public ArrayList<PublicKey> getECCPublicKeys(){
      ArrayList<PublicKey> publicKeys = new ArrayList<PublicKey>();
      publicKeys.add(keyPairA.getPublic());
      publicKeys.add(keyPairP.getPublic());
      return publicKeys;
    }
    public ArrayList<SecretKey> getSecretKeys(){
      ArrayList<SecretKey> secretKeys = new ArrayList<SecretKey>();
      secretKeys.add(secretSign);
      secretKeys.add(secretEncrypt);
      return secretKeys;
    }

    public String getCurveName(){
      return name;
    }
    public CA getCA(){
      return ca;
    }

    /* After calculating the n couples of (Bi, Qi), the SCMS sends them to the
    authority of certification. The CA ads a unqiue private key c to each couple,
    signs, encrypts and sends its result back to the SCMS that will transmit it
    finally to the device. The device will have to generate f1(ck, ι) and combine
    it with a and p in order to get bι and qι. This is the implemented formula :
    bι = a + f1(ck, ι) (signing keys)
    qι = p + f2(ek, ι) (encryption keys)
*/
    public void recieveFromScms(ArrayList<ECPoint> listBI, ArrayList<ECPoint> listQI, ArrayList<byte[]> listSignatures,
     ArrayList<BigInteger> listI, ArrayList<BigInteger> listC){
        ArrayList<BigInteger> listbi = new ArrayList<BigInteger>();
        BigInteger fieldSize = X962NamedCurves.getByName(name).getN();
        for(int j=0; j<listBI.size(); j++){
            BigInteger x1 = generate_X(listI.get(j)).get(0);
            BigInteger f1 = compute_f(secretSign, x1, fieldSize);
            BigInteger a = new BigInteger(keyPairA.getPrivate().toString().substring(31,95),16);
            BigInteger bi1 = a.add(f1);
            listbi.add(bi1.add(listC.get(j)));
            // A verifying function to check if we generated the right bi for each Bi
              ECPoint BiTest = generatorPoint.multiply(listbi.get(j));
              System.out.println("Test de la clé Bi (i = " + j + " ) " + BiTest.equals(listBI.get(j)));

        }
    }

    private ECPoint computeBi(BigInteger f1){
      return pointA.add(generatorPoint.multiply(f1));
    }


    /* The only difference between f1 and f2 is the generation of x1 and x2.
    For exmaple, to compute f1, we need to apply the following formula :
    f1(k, ι) = f1_int(k, ι) mod l
    With:
    1- l being the order of the elliptic curve
    2- f1_int(k, ι): the big-endian integer representation of
    (AES(k, x+1) XOR (x+1)) || (AES(k, x+2) XOR (x+2)) || (AES(k, x+3) XOR (x+3))
    */
    public BigInteger compute_f (SecretKey k, BigInteger x, BigInteger i){
      String res1 = compute_f_XOR(k, x, "1").toString() + compute_f_XOR(k, x, "2").toString() + compute_f_XOR(k, x, "3").toString();
      BigInteger res = new BigInteger(res1);

      // i is the order of the elliptic curve
      res = res.mod(i);
      return res ;
    }


    /* Calculate the (AES(k, x) XOR x). This function will be called upstairs
    three times before concatenation.
    */
    public BigInteger compute_f_XOR (SecretKey k, BigInteger x, String plus){
      BigInteger p = new BigInteger(plus);
      byte[] x_bytes = x.add(p).toByteArray();
      byte[] x_bytes_encrypt =  encryptAES(x_bytes, k);
      BigInteger x_Integ_encrypt = (new BigInteger (x_bytes_encrypt)).abs();
      return x_Integ_encrypt.xor(x.add(p));
    }

    // Use secret keys ck and ek to calculate AES(k, x)
    public byte[] encryptAES(byte[] x, SecretKey k){
      byte[] b = new byte[16];
      try{
            Cipher AesCipher = Cipher.getInstance("AES");
            AesCipher.init(Cipher.ENCRYPT_MODE, k);
            b   = AesCipher.doFinal(x);
      }catch (Exception e){
        e.printStackTrace();
      }
      return b;
    }

    /* In order to compute f, we need to get the 64 bits unique time period I.
    from the SCMS that generated it. Then we can generate the 128 bits
    x1 = (0³² || i || j || 0³²) and x2 = (1³² || i || j || 0³²).
    */
    public ArrayList<BigInteger> generate_X (BigInteger I) {
      // Construct the first 32 bits. It is the only difference between f1 and f2
      String x1 = "" ;
        for (int i = 0; i<32; i++ ){
          x1 = x1 + '0';
        }
      String x2 = "" ;
        for (int i = 0; i<32; i++ ){
          x2 = x2 + '1';
        }

      String II =  I.toString(2);
      // Add the time period and the final 32 bits to x1 and x2
      x1 = x1 + II;
      x2 = x2 + II;
      for (int i = 0; i<32; i++ ){
        x1= x1 + '0';
        x2= x2 + '0';
      }
      BigInteger xx1 = new BigInteger(x1,2);
      BigInteger xx2 = new BigInteger(x2,2);
      ArrayList<BigInteger> res = new ArrayList<BigInteger>();
      res.add(xx1);
      res.add(xx2);
      return res;
    }

    public KeyPair getKeyPairA(){
      return keyPairA;
    }
    public KeyPair getKeyPairP(){
      return keyPairP;
    }

}
