import org.bouncycastle.jce.spec.ECParameterSpec;
import java.security.KeyPairGenerator;
import java.security.Provider;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.KeyGenerator;
import javax.crypto.*;
import java.math.BigInteger;
import java.util.ArrayList;
import javax.crypto.Cipher;
import org.bouncycastle.math.ec.ECFieldElement;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.math.ec.ECCurve;
import java.math.*;
import java.util.Date;
import java.util.Random;
import java.security.Signature;



class CA{

    private PrivateKey privateKey;
    private PublicKey publicKey;
    private String name;

    public CA(String n){
      name = n;
      Security.addProvider(new BouncyCastleProvider());
      try {
          // Generate the public and private keys with ECC
          KeyPairGenerator kpg = KeyPairGenerator.getInstance("ECDSA", BouncyCastleProvider.PROVIDER_NAME);
          kpg.initialize(new ECGenParameterSpec(name));
          KeyPair keyPair = kpg.generateKeyPair();
          privateKey = keyPair.getPrivate();
          publicKey  = keyPair.getPublic();
      } catch(Exception e) {
          e.printStackTrace();
      }

}
      public void recieve(ArrayList<ECPoint> listBI, ArrayList<ECPoint> listQI, Scms scms){
        ArrayList <byte[]> listSignatures = new ArrayList<byte[]>();
        ArrayList<BigInteger> listC = generateC(listBI.size());


        X9ECParameters curveParam = X962NamedCurves.getByName(name);
        ECPoint generatorPoint = curveParam.getG();

        for(int i=0; i<listBI.size(); i++){
          listBI.set(i,listBI.get(i).add(generatorPoint.multiply(listC.get(i))));
          listQI.set(i,listQI.get(i).add(generatorPoint.multiply(listC.get(i))));
          String textToCipher = "(" + listBI.get(i).getX().toBigInteger().toString() + "," + listBI.get(i).getY().toBigInteger().toString()
                                + ")" + "," + listC.get(i).toString();

          // Chiffrer textToCipher avec QI
            //......
            try{
              Security.addProvider(new BouncyCastleProvider());
              Signature ecdsaSign = Signature.getInstance("SHA256withECDSA", "BC");
              ecdsaSign.initSign(privateKey);
              ecdsaSign.update(textToCipher.getBytes("UTF-8"));
              byte[] signature = ecdsaSign.sign();
              listSignatures.add(signature);
            }catch(Exception e){}
        }
        scms.recieveFromCA(listBI, listQI, listSignatures, listC);
      }

      public PublicKey getCAPublicKey(){
        return publicKey;
      }

      // Generate the list of random integer private keys c of the CA
      public ArrayList<BigInteger> generateC (int n){
        ArrayList<BigInteger> res = new ArrayList<BigInteger>();
        Random random;
        for (int i=0; i<n; i++){
          random = new Random ();
          res.add (new BigInteger(32, random));
        }
        return res;
      }
    }
