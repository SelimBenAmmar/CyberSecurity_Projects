import org.bouncycastle.jce.spec.ECParameterSpec;
import java.security.KeyPairGenerator;
import java.security.Provider;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.KeyGenerator;
import javax.crypto.*;
import java.math.BigInteger;
import java.util.ArrayList;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.*;
import java.math.*;
import java.util.Date;
import java.util.Random;

class Scms{

  Device device;
  private PublicKey publicKeyA;
  private PublicKey publicKeyP;
  private SecretKey secretSign;
  private SecretKey secretEncrypt;
  private ECPoint generatorPoint;
  private ECPoint pointA;
  private ECPoint pointP;
  private ArrayList<ECPoint> listBIPoints;
  private ArrayList<ECPoint> listQIPoints;
  private ArrayList<BigInteger> listI;

  public Scms(Device d){
    listQIPoints = new ArrayList<ECPoint>();
    listBIPoints = new ArrayList<ECPoint>();
    listI        = new ArrayList<BigInteger>();
    device = d;
    initKeys(device);
    initCurvParam(device);
  }

  /* The job of the SCMS is to use a signing (A) and an encryption (P) seed as
  well as expansion functions (f1) and (f2) to generate a large number of derived
  points (Bi) and (Qi). The device will then associate a private key (bi and qi)
  to each public point (Bi and Qi) and use the formed couples to transmit data.
  */
  public void start(int nb){
    computeListBIQI(nb);
  }

  /* The SCMS starts by generating an extremely large number of derived points BI and QI.
  Bι = A + f1(ck, ι) * G, with A = aG (signing keys)
  Qι = P + f2(ek, ι) * G, with P = pG (encryption keys)
  */

  private void computeListBIQI(int number){
    BigInteger fieldSize = X962NamedCurves.getByName(device.getCurveName()).getN();

    for(int j = 0; j<number; j++){
      /* For each new couple (point and private key), we generate unique time
      periode I, an x1 and x2 and therefore a unique f1(ck, ι) and f2(ek, ι)
      */
      ArrayList<BigInteger> arrayI_X = generateI_X();
      BigInteger I = arrayI_X.get(0);
      listI.add(I);
      BigInteger x1 = arrayI_X.get(1);
      BigInteger x2 = arrayI_X.get(2);

      // Compute Bi
        listBIPoints.add(computeBi(compute_f(secretSign, x1, fieldSize)));
      // Compute Qi
        listQIPoints.add(computeQi(compute_f(secretEncrypt, x2, fieldSize)));
    }

    // After computing listBIPoints and listQIPoints. We send these 2 arraylists to the CA
    device.getCA().recieve(listBIPoints, listQIPoints, this);
  }

  /* The CA receives the lists of both Bi and Qi. He modifies them, signs and
  encrypts the result before sending it back to the SCMS.
  */
  public void recieveFromCA(ArrayList<ECPoint> listBI, ArrayList<ECPoint> listQI, ArrayList<byte[]> listSignatures, ArrayList<BigInteger> listC){
    device.recieveFromScms(listBI, listQI, listSignatures, listI, listC);
  }

  /* We compute Bi with the following formula :
  Bι = A + f1(ck, ι) * G, with A = aG (signing keys)
  */
  private ECPoint computeBi(BigInteger f1){
    return pointA.add(generatorPoint.multiply(f1));
  }
  /* We compute Qi with the following formula :
  Qι = P + f2(ek, ι) * G, with P = pG (encryption keys)
  */
  private ECPoint computeQi(BigInteger f2){
    return pointP.add(generatorPoint.multiply(f2));
  }


  /* The only difference between f1 and f2 is the generation of x1 and x2.
  For exmaple, to compute f1, we need to apply the following formula :
  f1(k, ι) = f1_int(k, ι) mod l
  With:
  1- l being the order of the elliptic curve
  2- f1_int(k, ι): the big-endian integer representation of
  (AES(k, x+1) XOR (x+1)) || (AES(k, x+2) XOR (x+2)) || (AES(k, x+3) XOR (x+3))
  */
  public BigInteger compute_f (SecretKey k, BigInteger x, BigInteger i){
    String res1 = compute_f_XOR(k, x, "1").toString() + compute_f_XOR(k, x, "2").toString() + compute_f_XOR(k, x, "3").toString();
    BigInteger res = new BigInteger(res1);

    // i is the order of the elliptic curve
    res = res.mod(i);
    return res ;
  }


  /* Calculate the (AES(k, x) XOR x). This function will be called upstairs
  three times before concatenation.
  */
  public BigInteger compute_f_XOR (SecretKey k, BigInteger x, String plus){
    BigInteger p = new BigInteger(plus);
    byte[] x_bytes = x.add(p).toByteArray();
    byte[] x_bytes_encrypt =  encryptAES(x_bytes, k);
    BigInteger x_Integ_encrypt = (new BigInteger (x_bytes_encrypt)).abs();
    return x_Integ_encrypt.xor(x.add(p));
  }


  // Use secret keys ck and ek to calculate AES(k, x)
  public byte[] encryptAES(byte[] x, SecretKey k){
    byte[] b = new byte[16];
    try{
          Cipher AesCipher = Cipher.getInstance("AES");
          AesCipher.init(Cipher.ENCRYPT_MODE, k);
          b   = AesCipher.doFinal(x);
    }catch (Exception e){
      e.printStackTrace();
    }
    return b;
  }


  /* In order to compute f, we need to generate the 64 bits unique time period I.
  I =(i,j) with i (date from 1970 until know in milliseconds)
  and j(random integer).
  After generating I, we can generate the 128 bits
  x1 = (0³² || i || j || 0³²) and x2 = (1³² || i || j || 0³²)
  */
  public ArrayList<BigInteger> generateI_X () {
    // Construct the first 32 bits. It is the only difference between f1 and f2
    String x1 = "" ;
      for (int i = 0; i<32; i++ ){
        x1 = x1 + '0';
      }

    String x2 = "" ;
      for (int i = 0; i<32; i++ ){
        x2 = x2 + '1';
      }

    // Generate I the time period
    String I = "" ;
    // generate the first part of the time period
    Date date = new Date();
    int millisec = (int) date.getTime();
    String milliString = IntToString(millisec);
    I = I + milliString;
    // generate the second part of the time period
    Random random = new Random();
    String randString = IntToString(random.nextInt());
    I = I + randString;

    // Add the time period and the final 32 bits to x1 and x2
    x1 = x1 + I;
    x2 = x2 + I;
    for (int i = 0; i<32; i++ ){
      x1= x1 + '0';
      x2= x2 + '0';
    }
    BigInteger II = new BigInteger(I,2);
    BigInteger xx1 = new BigInteger(x1,2);
    BigInteger xx2 = new BigInteger(x2,2);
    ArrayList<BigInteger> res = new ArrayList<BigInteger>();
    res.add(II);
    res.add(xx1);
    res.add(xx2);
    return res;
  }

  /* Intermediate function to go from int to string.
  It is used to generate x and I in the function generateI_X.
  */
  public static String IntToString (int n) {
    String str = String.valueOf(n);
    BigInteger bigI = new BigInteger (str);
    byte[] arrayByte = bigI.toByteArray();
    String s = "";
    for (int i=0; i<arrayByte.length; i++){
      s = s + String.format("%8s", Integer.toBinaryString(arrayByte[i] & 0xFF)).replace(' ', '0');
    }
    return s ;
  }


  // Initialize public keys (publicKeyA publicKeyP) and secret keys (secretEncrypt secretSign) from device
    private void initKeys(Device d){
          ArrayList<PublicKey> pub = d.getECCPublicKeys();
          publicKeyA = pub.get(0);
          publicKeyP = pub.get(1);

          ArrayList<SecretKey> sec = d.getSecretKeys();
          secretSign    = sec.get(0);
          secretEncrypt = sec.get(1);
    }

    // initialize variables : generatorPoint, pointA, pointP (variables used to compute Bi and Qi)
    private void initCurvParam(Device d){
      X9ECParameters curveParam = X962NamedCurves.getByName(d.getCurveName());
      generatorPoint = curveParam.getG();

      //initialize pointA and pointP
      ECCurve.Fp curve = (ECCurve.Fp)curveParam.getCurve();
      // BigInteger q     = curve.getQ();
      String sA        = publicKeyA.toString();
      String sP        = publicKeyP.toString();

      pointA = curve.createPoint(new BigInteger(sA.substring(29,93),16),
                                  new BigInteger(sA.substring(109,173),16), false);;

      pointP = curve.createPoint(new BigInteger(sP.substring(29,93),16),
                                  new BigInteger(sP.substring(109,173),16), false);
    }

}
