import org.bouncycastle.jce.spec.ECParameterSpec;
import java.security.KeyPairGenerator;
import java.security.Provider;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.KeyGenerator;
import javax.crypto.*;
import java.math.BigInteger;
import java.security.Signature;



class proj{
    public static void main(String args[]){
      // We create a certificate authority CA, a device and an SCMS.
      CA ca = new CA("prime256v1");
      Device device = new Device("prime256v1", ca);
      Scms scms = new Scms(device);
      // 100 is the number of derived points we want to generate from the seed.

      // Test Génération clé publique/clé privé :
          Security.addProvider(new BouncyCastleProvider());

          System.out.println("//////////////////////////////////////////");
          System.out.println("//////////// Testing Key Pair A (Device) ///////////");
          System.out.println("//////////////////////////////////////////");
          System.out.println(device.getKeyPairA().getPublic().toString() + device.getKeyPairA().getPrivate().toString());
          testPairKey(device.getKeyPairA());
          System.out.println();

          System.out.println("//////////////////////////////////////////");
          System.out.println("//////////// Testing Key Pair P (Device) ///////////");
          System.out.println("//////////////////////////////////////////");
          System.out.println(device.getKeyPairP().getPublic().toString() + device.getKeyPairP().getPrivate().toString());
          testPairKey(device.getKeyPairP());
          System.out.println();

      // Test generation Bi
      scms.start(100);
    }

    public static void testPairKey(KeyPair keyPair){
      try{
        // ECDSA signature of message
        String plaintext = "Selim BEN AMMAR";
        Signature ecdsaSign = Signature.getInstance("SHA256withECDSA", "BC");
        ecdsaSign.initSign(keyPair.getPrivate());
        ecdsaSign.update(plaintext.getBytes("UTF-8"));
        byte[] signature = ecdsaSign.sign();

        // ECDSA verification of signature
        Signature ecdsaVerify = Signature.getInstance("SHA256withECDSA", "BC");
        ecdsaVerify.initVerify(keyPair.getPublic());
        ecdsaVerify.update(plaintext.getBytes("UTF-8"));
        boolean result = ecdsaVerify.verify(signature);

        System.out.println("Verifying Signature : " + result);

      }catch(Exception e){}
      }

}
